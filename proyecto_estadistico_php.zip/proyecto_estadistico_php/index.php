<?php
// index.php - Sistema Estadístico en PHP + JS (CSV/Encuesta)
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Sistema Web de Análisis Estadístico</title>
    <link rel="stylesheet" href="style.css">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>

<header class="header">
    <h1>Sistema Web de Análisis Estadístico</h1>
    <nav>
        <a href="#inicio">Inicio</a>
        <a href="#encuesta">Encuesta</a>
        <a href="#excel">Cargar CSV</a>
        <a href="#analisis">Análisis</a>
    </nav>
</header>

<main>

<!-- ====================== INICIO ====================== -->
<section id="inicio" class="card">
    <h2>Bienvenido</h2>
    <p>
        Este sistema permite cargar datos desde encuestas manuales o desde un archivo CSV
        (puedes exportar tu Excel a CSV) y generar:
    </p>
    <ul>
        <li>Tablas de frecuencia completas (numéricas y categóricas)</li>
        <li>Medidas de tendencia central, dispersión y posición</li>
        <li>Gráficas: histograma, polígono de frecuencias y ojiva</li>
    </ul>
</section>

<!-- ====================== ENCUESTA MANUAL ====================== -->
<section id="encuesta" class="card">
    <h2>Encuesta manual</h2>
    <p>Diseña una encuesta rápida y envía sus resultados al módulo de análisis.</p>

    <label>Número de preguntas:</label>
    <input type="number" id="numPreguntas" min="1" placeholder="Ej: 3">

    <label>Número de personas encuestadas:</label>
    <input type="number" id="numPersonas" min="1" placeholder="Ej: 10">

    <button class="btn" onclick="generarEstructuraEncuesta()">Generar estructura</button>

    <div id="zonaPreguntas" class="subcard" style="display:none;"></div>
    <div id="zonaRespuestas" class="subcard" style="display:none;"></div>
    <div id="zonaEnviarEncuesta" class="subcard" style="display:none;">
        <button class="btn btn-accent" onclick="enviarEncuesta()">Guardar encuesta y pasar a análisis</button>
    </div>
</section>

<!-- ====================== CARGA CSV ====================== -->
<section id="excel" class="card">
    <h2>Cargar archivo CSV (desde Excel)</h2>
    <p>
        Desde Excel puedes usar <b>Archivo → Guardar como → CSV (separado por comas)</b> y subirlo aquí.
    </p>
    <input type="file" id="csvFile" accept=".csv">
    <button class="btn" onclick="subirCSV()">Subir y procesar CSV</button>
    <p id="statusCSV" class="status-text"></p>
</section>

<!-- ====================== ANÁLISIS ====================== -->
<section id="analisis" class="card">
    <h2>Análisis estadístico</h2>

    <div id="zonaColumnas" class="subcard" style="display:none;">
        <h3>Seleccionar columna a analizar</h3>
        <select id="selectColumna" onchange="columnaCambiada()"></select>
    </div>

    <div id="zonaAcciones" class="acciones-analisis" style="display:none; margin-top:15px;">
        <button class="btn" onclick="cargarFrecuencias()">Tabla de frecuencias</button>
        <button class="btn" onclick="cargarMedidas()">Medidas estadísticas</button>
        <button class="btn btn-outline" onclick="mostrarGrafica()">Ver gráficas</button>
    </div>

    <div id="zonaFrecuencias" class="subcard" style="display:none;">
        <h3>Tabla de frecuencias</h3>
        <div id="tablaFrecuencias" class="tabla-frecuencia"></div>
    </div>

    <div id="zonaMedidas" class="subcard" style="display:none;">
        <h3>Medidas estadísticas</h3>
        <div id="medidasContenido"></div>
    </div>

    <div id="zonaGrafica" class="subcard" style="display:none;">
        <h3>Gráficas</h3>
        <div class="grafica-controles">
            <label for="tipoGrafica"><b>Tipo de gráfica:</b></label>
            <select id="tipoGrafica" onchange="redibujarGrafica()">
                <option value="hist">Histograma (numérica)</option>
                <option value="poligono">Polígono de frecuencias (numérica)</option>
                <option value="ojiva">Ojiva (numérica)</option>
                <option value="barras_cat">Barras categóricas</option>
            </select>
        </div>
        <div class="grafica-wrapper">
            <canvas id="graficaCanvas"></canvas>
        </div>
        <p class="nota-grafica">
            Nota: las gráficas numéricas se construyen con intervalos de clase; para variables categóricas usa
            la opción <b>"Barras categóricas"</b>.
        </p>
    </div>
</section>

</main>

<script src="script.js"></script>
</body>
</html>
