let columnaActual = null;
let datosFrecuencia = null;
let chart = null;

// ===== helper para formato de números =====
function fmt(x){
    if (x === null || x === undefined) return '';
    if (Number.isInteger(x)) return x.toString();
    return x.toFixed(3);
}

// =======================
// CARGA CSV DESDE EXCEL
// =======================
function subirCSV(){
    const input = document.getElementById('csvFile');
    const file = input.files[0];
    if(!file){
        alert('Seleccione un archivo CSV.');
        return;
    }
    const form = new FormData();
    form.append('file', file);

    fetch('api.php?action=upload_csv', {
        method: 'POST',
        body: form
    })
    .then(r => r.json())
    .then(d => {
        if(d.error){
            alert('Error: ' + d.error);
            return;
        }
        document.getElementById('statusCSV').textContent = 'CSV cargado correctamente.';
        llenarColumnas(d.columns);
    })
    .catch(err => {
        console.error(err);
        alert('Error al subir el CSV.');
    });
}

function llenarColumnas(columnas){
    const sel = document.getElementById('selectColumna');
    sel.innerHTML = '';
    columnas.forEach(c => {
        const opt = document.createElement('option');
        opt.value = c;
        opt.textContent = c;
        sel.appendChild(opt);
    });
    if(columnas.length > 0){
        columnaActual = columnas[0];
        document.getElementById('zonaColumnas').style.display = 'block';
        document.getElementById('zonaAcciones').style.display = 'flex';
    }
}

function columnaCambiada(){
    const sel = document.getElementById('selectColumna');
    columnaActual = sel.value;
}

// =======================
// ENCUESTA MANUAL
// =======================
let numPreg = 0;
let numPers = 0;
let preguntas = [];

function generarEstructuraEncuesta(){
    numPreg = parseInt(document.getElementById('numPreguntas').value);
    numPers = parseInt(document.getElementById('numPersonas').value);
    if(!numPreg || !numPers){
        alert('Ingrese número de preguntas y personas.');
        return;
    }

    let zonaP = document.getElementById('zonaPreguntas');
    zonaP.style.display = 'block';
    let htmlP = '<h3>Configurar preguntas</h3>';
    for(let i=0;i<numPreg;i++){
        htmlP += `
        <div class="pregunta-config">
            <label>Pregunta ${i+1}:</label>
            <input type="text" id="preg_text_${i}" placeholder="Ej: Edad, Ingreso diario">
            <label>Tipo de dato:</label>
            <select id="preg_tipo_${i}">
                <option value="num">Numérico</option>
                <option value="texto">Texto / Categoría</option>
            </select>
        </div>`;
    }
    zonaP.innerHTML = htmlP;

    let zonaR = document.getElementById('zonaRespuestas');
    zonaR.style.display = 'block';
    let htmlR = '<h3>Respuestas</h3>';
    htmlR += '<div class="tabla-scroll"><table><thead><tr><th>Persona</th>';
    for(let i=0;i<numPreg;i++){
        htmlR += '<th>P'+(i+1)+'</th>';
    }
    htmlR += '</tr></thead><tbody>';
    for(let p=0;p<numPers;p++){
        htmlR += '<tr><td>'+(p+1)+'</td>';
        for(let j=0;j<numPreg;j++){
            htmlR += '<td><input type="text" id="resp_'+p+'_'+j+'"></td>';
        }
        htmlR += '</tr>';
    }
    htmlR += '</tbody></table></div>';
    zonaR.innerHTML = htmlR;

    document.getElementById('zonaEnviarEncuesta').style.display = 'block';
}

function enviarEncuesta(){
    preguntas = [];
    for(let i=0;i<numPreg;i++){
        let texto = document.getElementById('preg_text_'+i).value || ('Pregunta '+(i+1));
        let tipo = document.getElementById('preg_tipo_'+i).value;
        preguntas.push({texto, tipo});
    }

    let data = [];
    for(let p=0;p<numPers;p++){
        let fila = {};
        for(let j=0;j<numPreg;j++){
            let key = preguntas[j].texto;
            let val = document.getElementById('resp_'+p+'_'+j).value;
            fila[key] = val;
        }
        data.push(fila);
    }

    fetch('api.php?action=save_dataset', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({data})
    })
    .then(r => r.json())
    .then(d => {
        if(d.error){
            alert('Error: ' + d.error);
            return;
        }
        alert('Encuesta guardada. Ahora puedes analizar las columnas.');
        llenarColumnas(d.columns);
        location.hash = '#analisis';
    })
    .catch(err => {
        console.error(err);
        alert('Error al guardar encuesta.');
    });
}

// =======================
// TABLA DE FRECUENCIAS
// =======================
function cargarFrecuencias(){
    if(!columnaActual){
        alert('Seleccione una columna.');
        return;
    }
    fetch('api.php?action=frequencies', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({column: columnaActual})
    })
    .then(r => r.json())
    .then(d => {
        if(d.error){
            alert('Error: ' + d.error);
            return;
        }
        datosFrecuencia = d; // aquí viene simple + agrupada
        mostrarTablaFrecuencias(d);
    })
    .catch(err => {
        console.error(err);
        alert('Error al obtener frecuencias.');
    });
}

function mostrarTablaFrecuencias(d){
    const cont = document.getElementById('tablaFrecuencias');
    let html = '';

    // ===== CATEGÓRICA =====
    if(d.tipo === 'categorica'){
        html += `<div class="resumen-frecuencia">
                    <div><span class="label">Variable:</span> Categórica</div>
                    <div><span class="label">n:</span> ${d.n}</div>
                </div>`;

        html += '<div class="tabla-scroll"><table><thead><tr>';
        html += '<th>Categoría</th><th>F</th><th>FA</th><th>FR</th><th>FRA</th><th>FR%</th><th>FRA%</th>';
        html += '</tr></thead><tbody>';

        let totalF = 0;
        let totalFA = 0;

        d.tabla.forEach(fila => {
            totalF += fila.f;
            totalFA = fila.fa;

            html += `<tr>
                <td class="text-left">${fila.categoria}</td>
                <td>${fila.f}</td>
                <td>${fila.fa}</td>
                <td>${fmt(fila.fr)}</td>
                <td>${fmt(fila.fra)}</td>
                <td>${(fila.fr * 100).toFixed(2)}%</td>
                <td>${(fila.fra * 100).toFixed(2)}%</td>
            </tr>`;
        });

        html += `<tr class="fila-total">
            <td><b>TOTAL</b></td>
            <td><b>${totalF}</b></td>
            <td><b>${totalFA}</b></td>
            <td><b>1.000</b></td>
            <td><b>1.000</b></td>
            <td><b>100.00%</b></td>
            <td><b>100.00%</b></td>
        </tr>`;

        html += '</tbody></table></div>';
        cont.innerHTML = html;
        document.getElementById('zonaFrecuencias').style.display = 'block';
        return;
    }

    // ===== NUMÉRICA: TABLA SIMPLE GRANDE POR VALOR =====
    const simple = d.simple || [];
    if(simple.length === 0){
        cont.innerHTML = '<p>No hay datos numéricos para esta columna.</p>';
        document.getElementById('zonaFrecuencias').style.display = 'block';
        return;
    }

    const min = simple[0].valor;
    const max = simple[simple.length - 1].valor;

    html += `<div class="resumen-frecuencia">
                <div><span class="label">Variable:</span> Numérica (detalle por valor)</div>
                <div><span class="label">n:</span> ${d.n}</div>
                <div><span class="label">mín:</span> ${fmt(min)}</div>
                <div><span class="label">máx:</span> ${fmt(max)}</div>
                <div><span class="label">Rango (R):</span> ${fmt(d.rango)}</div>
                <div><span class="label">Media (x̄):</span> ${fmt(d.media)}</div>
            </div>`;

    html += '<div class="tabla-scroll"><table><thead><tr>';
    html += '<th>Valor</th>';
    html += '<th>F</th>';
    html += '<th>FA</th>';
    html += '<th>FR</th>';
    html += '<th>FRA</th>';
    html += '<th>FR%</th>';
    html += '<th>FRA%</th>';
    html += '<th>(X - x̄)</th>';
    html += '<th>(X - x̄)²</th>';
    html += '<th>(X - x̄)²·F</th>';
    html += '</tr></thead><tbody>';

    let totalF = 0;
    let totalFA = 0;
    let totalFDesv2 = 0;

    simple.forEach(fila => {
        totalF += fila.f;
        totalFA = fila.fa;
        const FR = fila.fr;
        const FRA = fila.fra;
        totalFDesv2 += fila.fdesv2;

        html += `<tr>
            <td>${fmt(fila.valor)}</td>
            <td>${fila.f}</td>
            <td>${fila.fa}</td>
            <td>${fmt(FR)}</td>
            <td>${fmt(FRA)}</td>
            <td>${(FR*100).toFixed(2)}%</td>
            <td>${(FRA*100).toFixed(2)}%</td>
            <td>${fmt(fila.desv)}</td>
            <td>${fmt(fila.desv2)}</td>
            <td>${fmt(fila.fdesv2)}</td>
        </tr>`;
    });

    html += `<tr class="fila-total">
        <td><b>TOTAL</b></td>
        <td><b>${totalF}</b></td>
        <td><b>${totalFA}</b></td>
        <td><b>1.000</b></td>
        <td><b>1.000</b></td>
        <td><b>100.00%</b></td>
        <td><b>100.00%</b></td>
        <td>—</td>
        <td>—</td>
        <td><b>${fmt(totalFDesv2)}</b></td>
    </tr>`;

    html += '</tbody></table></div>';

    cont.innerHTML = html;
    document.getElementById('zonaFrecuencias').style.display = 'block';
}

// =======================
// MEDIDAS ESTADÍSTICAS
// =======================
function cargarMedidas(){
    if(!columnaActual){
        alert('Seleccione una columna.');
        return;
    }
    fetch('api.php?action=measures', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({column: columnaActual})
    })
    .then(r => r.json())
    .then(m => {
        if(m.error){
            alert('Error: ' + m.error);
            return;
        }
        mostrarMedidas(m);
    })
    .catch(err => {
        console.error(err);
        alert('Error al obtener medidas.');
    });
}

function mostrarMedidas(m){
    let html = '';
    html += `<div class="grid-medidas">
                <div><span class="label">n:</span> ${m.n}</div>
                <div><span class="label">Media:</span> ${fmt(m.media)}</div>
                <div><span class="label">Mediana:</span> ${fmt(m.mediana)}</div>
                <div><span class="label">Moda:</span> ${fmt(m.moda)}</div>
                <div><span class="label">Rango:</span> ${fmt(m.rango)}</div>
                <div><span class="label">Varianza:</span> ${fmt(m.varianza)}</div>
                <div><span class="label">Desv. estándar:</span> ${fmt(m.desviacion)}</div>
                <div><span class="label">CV:</span> ${m.cv !== null ? m.cv.toFixed(2)+'%' : '—'}</div>
            </div>`;

    html += '<h4>Cuartiles</h4>';
    html += `<p>Q1: ${fmt(m.q1)} &nbsp; Q2: ${fmt(m.q2)} &nbsp; Q3: ${fmt(m.q3)}</p>`;

    html += '<h4>Deciles</h4><ul class="lista-flex">';
    for(let i=1;i<=9;i++){
        const key = 'D'+i;
        html += `<li>${key}: ${fmt(m.deciles[key])}</li>`;
    }
    html += '</ul>';

    html += '<h4>Percentiles (ejemplo)</h4><ul class="lista-flex">';
    for(const key in m.percentiles){
        html += `<li>${key}: ${fmt(m.percentiles[key])}</li>`;
    }
    html += '</ul>';

    document.getElementById('medidasContenido').innerHTML = html;
    document.getElementById('zonaMedidas').style.display = 'block';
}

// =======================
// GRÁFICAS (siguen usando tabla agrupada)
// =======================
function mostrarGrafica(){
    if(!datosFrecuencia){
        alert('Primero genera la tabla de frecuencias.');
        return;
    }
    document.getElementById('zonaGrafica').style.display = 'block';
    redibujarGrafica();
}

function redibujarGrafica(){
    if(!datosFrecuencia){
        return;
    }
    const select = document.getElementById('tipoGrafica');
    const tipo = select ? select.value : 'hist';

    if(chart){
        chart.destroy();
    }

    const ctx = document.getElementById('graficaCanvas').getContext('2d');

    const commonOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { display: true, position: 'top' },
            tooltip: { enabled: true }
        },
        scales: {
            x: { title: { display: true, text: '' } },
            y: { beginAtZero: true, title: { display: true, text: '' } }
        }
    };

    // Categórica -> barras por categoría
    if(datosFrecuencia.tipo === 'categorica'){
        const labels = datosFrecuencia.tabla.map(f => f.categoria);
        const data = datosFrecuencia.tabla.map(f => f.f);

        commonOptions.scales.x.title.text = 'Categorías';
        commonOptions.scales.y.title.text = 'Frecuencia';

        chart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets:[{
                    label: 'Frecuencia',
                    data: data
                }]
            },
            options: commonOptions
        });
        return;
    }

    // Numérica -> usa tabla agrupada para las gráficas
    const tablaAgr = datosFrecuencia.tabla || [];
    if(tablaAgr.length === 0){
        alert('No hay tabla agrupada disponible para graficar.');
        return;
    }

    if(tipo === 'hist'){
        const labels = tablaAgr.map(f => f.marca.toFixed(2));
        const data = tablaAgr.map(f => f.f);

        commonOptions.scales.x.title.text = 'Marca de clase';
        commonOptions.scales.y.title.text = 'Frecuencia';

        chart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets:[{
                    label: 'Frecuencia (fi)',
                    data: data
                }]
            },
            options: commonOptions
        });
    } else if(tipo === 'poligono'){
        const labels = tablaAgr.map(f => f.marca.toFixed(2));
        const data = tablaAgr.map(f => f.f);

        commonOptions.scales.x.title.text = 'Marca de clase';
        commonOptions.scales.y.title.text = 'Frecuencia';

        chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets:[{
                    label: 'Polígono de frecuencias',
                    data: data,
                    tension: 0.25
                }]
            },
            options: commonOptions
        });
    } else if(tipo === 'ojiva'){
        const labels = tablaAgr.map(f => f.ls.toFixed(2));
        const data = tablaAgr.map(f => f.fa);

        commonOptions.scales.x.title.text = 'Límite superior de clase';
        commonOptions.scales.y.title.text = 'Frecuencia acumulada';

        chart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets:[{
                    label: 'Ojiva (FA)',
                    data: data,
                    tension: 0.25
                }]
            },
            options: commonOptions
        });
    }
}
