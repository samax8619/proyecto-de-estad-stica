<?php
session_start();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['dataset'])) {
    $_SESSION['dataset'] = null;
}

function respond($data, $code = 200){
    http_response_code($code);
    echo json_encode($data);
    exit;
}

// Limpieza de valores tipo "35 años", "$35.000", "1,5", etc.
function toNumeric($value){
    $s = (string)$value;
    $s = str_replace('años', '', $s);
    $s = str_replace('$', '', $s);
    $s = str_replace('%', '', $s);
    $s = str_replace(' ', '', $s);
    $s = str_replace('.', '', $s);   // quita puntos de miles
    $s = str_replace(',', '.', $s);  // coma decimal -> punto
    if ($s === '' || !is_numeric($s)) {
        return null;
    }
    return floatval($s);
}

$action = $_GET['action'] ?? '';

/* =======================
   SUBIR CSV
   ======================= */
if ($action === 'upload_csv') {
    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        respond(['error' => 'No se recibió el archivo CSV o hubo un error al subir.'], 400);
    }
    $tmp = $_FILES['file']['tmp_name'];
    $handle = fopen($tmp, 'r');
    if (!$handle) respond(['error' => 'No se pudo abrir el archivo CSV.'], 500);

    $header = fgetcsv($handle);
    if ($header === false) respond(['error' => 'El CSV está vacío o es inválido.'], 400);

    $dataset = [];
    while (($row = fgetcsv($handle)) !== false) {
        $fila = [];
        foreach ($header as $i => $colName) {
            $fila[$colName] = $row[$i] ?? null;
        }
        $dataset[] = $fila;
    }
    fclose($handle);

    if (count($dataset) === 0) respond(['error' => 'El CSV no contiene filas de datos.'], 400);

    $_SESSION['dataset'] = $dataset;
    respond(['status' => 'ok', 'columns' => array_keys($dataset[0])]);
}

/* =======================
   GUARDAR DATASET (ENCUESTA)
   ======================= */
if ($action === 'save_dataset') {
    $raw = file_get_contents('php://input');
    $json = json_decode($raw, true);
    if (!$json || !isset($json['data']) || !is_array($json['data'])) {
        respond(['error' => 'Formato JSON inválido.'], 400);
    }
    $data = $json['data'];
    if (count($data) === 0) respond(['error' => 'Dataset vacío.'], 400);

    $_SESSION['dataset'] = $data;
    respond(['status' => 'ok', 'columns' => array_keys($data[0])]);
}

/* =======================
   OBTENER COLUMNAS
   ======================= */
if ($action === 'get_columns') {
    $dataset = $_SESSION['dataset'];
    if (!$dataset) respond(['error' => 'No hay datos cargados.'], 400);
    respond(['columns' => array_keys($dataset[0])]);
}

/* =======================
   TABLA DE FRECUENCIAS
   (CATEGÓRICA / NUMÉRICA SIMPLE + AGRUPADA)
   ======================= */
if ($action === 'frequencies') {
    $dataset = $_SESSION['dataset'];
    if (!$dataset) respond(['error' => 'No hay datos cargados.'], 400);

    $raw = file_get_contents('php://input');
    $json = json_decode($raw, true);
    $col = $json['column'] ?? null;
    if (!$col || !array_key_exists($col, $dataset[0])) {
        respond(['error' => 'Columna no válida.'], 400);
    }

    // 1. Intentar como numérica
    $nums = [];
    foreach ($dataset as $row) {
        if (!isset($row[$col])) continue;
        $val = toNumeric($row[$col]);
        if ($val !== null) $nums[] = $val;
    }
    $n = count($nums);

    /* ===== CASO: NO HAY NÚMEROS -> FRECUENCIA CATEGÓRICA ===== */
    if ($n === 0) {
        $freq = [];
        $total = 0;
        foreach ($dataset as $row) {
            if (!isset($row[$col])) continue;
            $val = trim((string)$row[$col]);
            if ($val === '') continue;
            if (!isset($freq[$val])) $freq[$val] = 0;
            $freq[$val]++;
            $total++;
        }

        if ($total === 0) {
            respond(['error' => 'La columna está vacía.'], 400);
        }

        arsort($freq); // categorías ordenadas por frecuencia

        $fa = 0;
        $tabla = [];
        foreach ($freq as $categoria => $f) {
            $fa += $f;
            $fr = $f / $total;
            $fra = $fa / $total;
            $tabla[] = [
                'categoria' => $categoria,
                'f' => $f,
                'fa' => $fa,
                'fr' => $fr,
                'fra' => $fra
            ];
        }

        respond([
            'tipo' => 'categorica',
            'n' => $total,
            'tabla' => $tabla
        ]);
    }

    /* ===== CASO: SÍ HAY NÚMEROS -> FRECUENCIA NUMÉRICA ===== */
    sort($nums);
    $min = $nums[0];
    $max = $nums[$n-1];
    $rango = $max - $min;

    // Media REAL usando todos los datos
    $sum = array_sum($nums);
    $media = $sum / $n;

    // ---- TABLA SIMPLE (por valor) ----
    $freq_map = [];
    foreach ($nums as $v) {
        $key = strval($v);
        if (!isset($freq_map[$key])) $freq_map[$key] = 0;
        $freq_map[$key]++;
    }
    ksort($freq_map, SORT_NUMERIC);

    $fa_simple = 0;
    $tabla_simple = [];
    foreach ($freq_map as $key => $f) {
        $valor = floatval($key);
        $fa_simple += $f;
        $fr = $f / $n;
        $fra = $fa_simple / $n;

        $desv = $valor - $media;
        $desv2 = $desv * $desv;
        $fdesv2 = $desv2 * $f;

        $tabla_simple[] = [
            'valor' => $valor,
            'f' => $f,
            'fa' => $fa_simple,
            'fr' => $fr,
            'fra' => $fra,
            'desv' => $desv,
            'desv2' => $desv2,
            'fdesv2' => $fdesv2
        ];
    }

    // ---- TABLA AGRUPADA (solo para gráficas) ----
    $k = (int) round(1 + 3.322 * log10($n));
    if ($k < 1) $k = 1;

    $amplitud = ($rango == 0) ? 1 : ceil($rango / $k);
    $amplitud = floatval($amplitud);

    $bordes = [];
    for ($i=0; $i <= $k; $i++) {
        $bordes[] = $min + $i * $amplitud;
    }

    $clases = [];
    for ($i=0; $i < $k; $i++) {
        $li = $bordes[$i];
        $ls = $bordes[$i+1];
        $marca = ($li + $ls) / 2.0;
        $clases[] = [
            'li' => $li,
            'ls' => $ls,
            'marca' => $marca,
            'f' => 0,
            'fa' => 0,
            'fr' => 0.0,
            'fra' => 0.0,
            'fx' => 0.0,
            'desv2' => 0.0,
            'fdesv2' => 0.0
        ];
    }

    foreach ($nums as $v) {
        for ($i=0; $i < $k; $i++) {
            $li = $clases[$i]['li'];
            $ls = $clases[$i]['ls'];
            if (($v >= $li && $v < $ls) || ($i == $k-1 && $v == $ls)) {
                $clases[$i]['f']++;
                break;
            }
        }
    }

    $total = floatval($n);
    $fa = 0;
    $sum_fx = 0.0;
    for ($i=0; $i < $k; $i++) {
        $f = $clases[$i]['f'];
        $fa += $f;
        $clases[$i]['fa'] = $fa;
        $clases[$i]['fr'] = $f / $total;
        $clases[$i]['fra'] = $fa / $total;
        $fx = $clases[$i]['marca'] * $f;
        $clases[$i]['fx'] = $fx;
        $sum_fx += $fx;
    }

    // usamos la misma media real para las desviaciones agrupadas
    for ($i=0; $i < $k; $i++) {
        $desv2 = pow($clases[$i]['marca'] - $media, 2);
        $clases[$i]['desv2'] = $desv2;
        $clases[$i]['fdesv2'] = $desv2 * $clases[$i]['f'];
    }

    respond([
        'tipo' => 'numerica',
        'n' => $n,
        'min' => $min,
        'max' => $max,
        'rango' => $rango,
        'media' => $media,
        'simple' => $tabla_simple, // tabla que verás en la interfaz
        'tabla' => $clases,        // agrupada para gráficas
        'k' => $k,
        'amplitud' => $amplitud
    ]);
}

/* =======================
   MEDIDAS ESTADÍSTICAS (SOLO NUMÉRICAS)
   ======================= */
if ($action === 'measures') {
    $dataset = $_SESSION['dataset'];
    if (!$dataset) respond(['error' => 'No hay datos cargados.'], 400);

    $raw = file_get_contents('php://input');
    $json = json_decode($raw, true);
    $col = $json['column'] ?? null;
    if (!$col || !array_key_exists($col, $dataset[0])) {
        respond(['error' => 'Columna no válida.'], 400);
    }

    $nums = [];
    foreach ($dataset as $row) {
        if (!isset($row[$col])) continue;
        $val = toNumeric($row[$col]);
        if ($val !== null) $nums[] = $val;
    }

    $n = count($nums);
    if ($n === 0) respond(['error' => 'No hay datos numéricos válidos en esa columna.'], 400);

    sort($nums);

    $sum = array_sum($nums);
    $media = $sum / $n;

    if ($n % 2 == 1) {
        $mediana = $nums[intval(($n-1)/2)];
    } else {
        $mediana = ($nums[$n/2 - 1] + $nums[$n/2]) / 2.0;
    }

    $freq = [];
    foreach ($nums as $v) {
        $key = strval($v);
        if (!isset($freq[$key])) $freq[$key] = 0;
        $freq[$key]++;
    }
    arsort($freq);
    $moda = floatval(array_key_first($freq));

    $rango = $nums[$n-1] - $nums[0];

    if ($n > 1) {
        $sum_sq = 0.0;
        foreach ($nums as $v) {
            $sum_sq += pow($v - $media, 2);
        }
        $varianza = $sum_sq / ($n - 1);
        $desviacion = sqrt($varianza);
    } else {
        $varianza = 0.0;
        $desviacion = 0.0;
    }

    $cv = ($media != 0.0) ? ($desviacion / $media) * 100.0 : null;

    $quantile = function($arr, $p){
        $n = count($arr);
        if ($n == 1) return $arr[0];
        $pos = ($n - 1) * $p;
        $floor = floor($pos);
        $ceil = ceil($pos);
        if ($floor == $ceil) return $arr[$floor];
        $d = $pos - $floor;
        return $arr[$floor] + $d * ($arr[$ceil] - $arr[$floor]);
    };

    $q1 = $quantile($nums, 0.25);
    $q2 = $quantile($nums, 0.50);
    $q3 = $quantile($nums, 0.75);

    $deciles = [];
    for ($i=1; $i<=9; $i++) {
        $deciles['D'.$i] = $quantile($nums, $i/10.0);
    }

    $percentiles = [];
    foreach ([10,25,50,75,90] as $p) {
        $percentiles['P'.$p] = $quantile($nums, $p/100.0);
    }

    respond([
        'n' => $n,
        'media' => $media,
        'mediana' => $mediana,
        'moda' => $moda,
        'rango' => $rango,
        'varianza' => $varianza,
        'desviacion' => $desviacion,
        'cv' => $cv,
        'q1' => $q1,
        'q2' => $q2,
        'q3' => $q3,
        'deciles' => $deciles,
        'percentiles' => $percentiles
    ]);
}

respond(['error' => 'Acción no válida.'], 400);
